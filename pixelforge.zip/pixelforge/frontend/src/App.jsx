import { useState, useRef, useCallback, useEffect } from "react";

const API_BASE = "http://localhost:8000";

const PALETTES = [
  { id: null, label: "Auto", emoji: "🎨" },
  { id: "gameboy", label: "Game Boy", emoji: "🟩" },
  { id: "nes", label: "NES", emoji: "🕹️" },
  { id: "commodore64", label: "C64", emoji: "💾" },
  { id: "pastel", label: "Pastel", emoji: "🌸" },
  { id: "cyberpunk", label: "Cyberpunk", emoji: "⚡" },
];

const PRESETS = [
  { label: "8-bit Classic", pixel_size: 16, num_colors: 8, palette: "nes" },
  { label: "Game Boy", pixel_size: 12, num_colors: 4, palette: "gameboy" },
  { label: "Retro PC", pixel_size: 10, num_colors: 16, palette: "commodore64" },
  { label: "Vaporwave", pixel_size: 8, num_colors: 32, palette: "cyberpunk" },
  { label: "Fine Art", pixel_size: 4, num_colors: 64, palette: null },
  { label: "Mosaic", pixel_size: 24, num_colors: 24, palette: null },
];

function Slider({ label, value, min, max, step = 1, onChange, unit = "" }) {
  return (
    <div style={{ marginBottom: 18 }}>
      <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 6 }}>
        <span style={{ color: "#c9d1e0", fontSize: 13, fontFamily: "'Space Mono', monospace" }}>{label}</span>
        <span style={{ color: "#7ef4cc", fontSize: 13, fontFamily: "'Space Mono', monospace", fontWeight: 700 }}>
          {value}{unit}
        </span>
      </div>
      <input
        type="range"
        min={min}
        max={max}
        step={step}
        value={value}
        onChange={(e) => onChange(Number(e.target.value))}
        style={{
          width: "100%",
          accentColor: "#7ef4cc",
          height: 6,
          borderRadius: 3,
          cursor: "pointer",
          background: `linear-gradient(to right, #7ef4cc ${((value - min) / (max - min)) * 100}%, #1e2a3a ${((value - min) / (max - min)) * 100}%)`,
        }}
      />
    </div>
  );
}

function Toggle({ label, checked, onChange }) {
  return (
    <label style={{ display: "flex", alignItems: "center", gap: 10, cursor: "pointer", marginBottom: 14 }}>
      <div
        onClick={() => onChange(!checked)}
        style={{
          width: 42,
          height: 24,
          borderRadius: 12,
          background: checked ? "#7ef4cc" : "#1e2a3a",
          border: `1.5px solid ${checked ? "#7ef4cc" : "#3a4a5a"}`,
          position: "relative",
          transition: "all 0.2s",
          flexShrink: 0,
        }}
      >
        <div
          style={{
            position: "absolute",
            top: 3,
            left: checked ? 20 : 3,
            width: 16,
            height: 16,
            borderRadius: "50%",
            background: checked ? "#0a1628" : "#7a8a9a",
            transition: "left 0.2s",
          }}
        />
      </div>
      <span style={{ color: "#c9d1e0", fontSize: 13, fontFamily: "'Space Mono', monospace" }}>{label}</span>
    </label>
  );
}

export default function PixelForge() {
  const [uploadedB64, setUploadedB64] = useState(null);
  const [resultB64, setResultB64] = useState(null);
  const [filename, setFilename] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [prompt, setPrompt] = useState("");
  const [activeTab, setActiveTab] = useState("upload");
  const [dragOver, setDragOver] = useState(false);
  const [progress, setProgress] = useState(0);

  const [pixelSize, setPixelSize] = useState(16);
  const [numColors, setNumColors] = useState(16);
  const [protectFaces, setProtectFaces] = useState(true);
  const [facePixelSize, setFacePixelSize] = useState(8);
  const [addGrid, setAddGrid] = useState(false);
  const [palette, setPalette] = useState(null);

  const fileRef = useRef();

  // Animated progress bar
  useEffect(() => {
    let interval;
    if (loading) {
      setProgress(5);
      interval = setInterval(() => {
        setProgress((p) => (p < 85 ? p + Math.random() * 8 : p));
      }, 300);
    } else {
      setProgress(100);
      const t = setTimeout(() => setProgress(0), 600);
      return () => clearTimeout(t);
    }
    return () => clearInterval(interval);
  }, [loading]);

  const handleFile = useCallback((file) => {
    if (!file || !file.type.startsWith("image/")) {
      setError("Please upload an image file (JPG, PNG, WEBP, etc.)");
      return;
    }
    const reader = new FileReader();
    reader.onload = (e) => {
      setUploadedB64(e.target.result);
      setResultB64(null);
      setError(null);
    };
    reader.readAsDataURL(file);
  }, []);

  const onDrop = useCallback(
    (e) => {
      e.preventDefault();
      setDragOver(false);
      const file = e.dataTransfer.files[0];
      handleFile(file);
    },
    [handleFile]
  );

  const process = async () => {
    if (!uploadedB64) return;
    setLoading(true);
    setError(null);
    try {
      const resp = await fetch(`${API_BASE}/process`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          image_b64: uploadedB64,
          pixel_size: pixelSize,
          num_colors: numColors,
          protect_faces: protectFaces,
          face_pixel_size: facePixelSize,
          add_grid: addGrid,
          palette,
        }),
      });
      const data = await resp.json();
      if (!resp.ok) throw new Error(data.detail || "Processing failed");
      setResultB64(data.result_b64);
      setFilename(data.filename);
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  const generate = async () => {
    if (!prompt.trim()) return;
    setLoading(true);
    setError(null);
    try {
      const form = new FormData();
      form.append("prompt", prompt);
      form.append("style", palette || "pixel");
      const resp = await fetch(`${API_BASE}/generate-prompt`, {
        method: "POST",
        body: form,
      });
      const data = await resp.json();
      if (!resp.ok) throw new Error(data.detail || "Generation failed");
      setResultB64(data.result_b64);
      setFilename(data.filename);
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  const applyPreset = (preset) => {
    setPixelSize(preset.pixel_size);
    setNumColors(preset.num_colors);
    setPalette(preset.palette);
  };

  const download = () => {
    if (!resultB64) return;
    const a = document.createElement("a");
    a.href = resultB64;
    a.download = filename || "pixelforge_output.png";
    a.click();
  };

  const styles = {
    app: {
      minHeight: "100vh",
      background: "linear-gradient(135deg, #060d1a 0%, #0a1628 50%, #060d1a 100%)",
      fontFamily: "'Space Mono', 'Courier New', monospace",
      color: "#e8edf5",
      padding: "0 0 60px",
      position: "relative",
      overflow: "hidden",
    },
    grid: {
      position: "fixed",
      inset: 0,
      backgroundImage:
        "linear-gradient(rgba(126,244,204,0.04) 1px, transparent 1px), linear-gradient(90deg, rgba(126,244,204,0.04) 1px, transparent 1px)",
      backgroundSize: "40px 40px",
      pointerEvents: "none",
      zIndex: 0,
    },
    content: { position: "relative", zIndex: 1 },
    header: {
      textAlign: "center",
      padding: "50px 20px 30px",
      borderBottom: "1px solid rgba(126,244,204,0.1)",
      marginBottom: 40,
    },
    logo: {
      fontSize: 48,
      fontWeight: 900,
      letterSpacing: "-2px",
      background: "linear-gradient(120deg, #7ef4cc, #4dd9f0, #a78bfa)",
      WebkitBackgroundClip: "text",
      WebkitTextFillColor: "transparent",
      marginBottom: 6,
    },
    tagline: { color: "#5a7a8a", fontSize: 13, letterSpacing: 3 },
    main: {
      maxWidth: 1200,
      margin: "0 auto",
      padding: "0 20px",
      display: "grid",
      gridTemplateColumns: "340px 1fr",
      gap: 24,
    },
    panel: {
      background: "rgba(14,22,38,0.9)",
      border: "1px solid rgba(126,244,204,0.15)",
      borderRadius: 16,
      padding: 24,
      backdropFilter: "blur(10px)",
    },
    sectionTitle: {
      fontSize: 11,
      letterSpacing: 3,
      color: "#7ef4cc",
      marginBottom: 16,
      textTransform: "uppercase",
    },
    tabRow: { display: "flex", gap: 8, marginBottom: 20 },
    tab: (active) => ({
      flex: 1,
      padding: "10px 0",
      borderRadius: 8,
      border: `1px solid ${active ? "#7ef4cc" : "rgba(126,244,204,0.2)"}`,
      background: active ? "rgba(126,244,204,0.12)" : "transparent",
      color: active ? "#7ef4cc" : "#5a7a8a",
      cursor: "pointer",
      fontSize: 12,
      fontFamily: "'Space Mono', monospace",
      transition: "all 0.2s",
    }),
    dropzone: (over) => ({
      border: `2px dashed ${over ? "#7ef4cc" : "rgba(126,244,204,0.3)"}`,
      borderRadius: 12,
      padding: 30,
      textAlign: "center",
      cursor: "pointer",
      transition: "all 0.2s",
      background: over ? "rgba(126,244,204,0.05)" : "transparent",
      marginBottom: 16,
    }),
    btn: (variant = "primary") => ({
      width: "100%",
      padding: "13px 0",
      borderRadius: 10,
      border: "none",
      cursor: "pointer",
      fontSize: 13,
      fontFamily: "'Space Mono', monospace",
      fontWeight: 700,
      letterSpacing: 1,
      transition: "all 0.2s",
      ...(variant === "primary"
        ? {
            background: "linear-gradient(135deg, #7ef4cc, #4dd9f0)",
            color: "#060d1a",
          }
        : {
            background: "rgba(126,244,204,0.1)",
            color: "#7ef4cc",
            border: "1px solid rgba(126,244,204,0.3)",
          }),
    }),
    presetGrid: {
      display: "grid",
      gridTemplateColumns: "1fr 1fr",
      gap: 8,
      marginBottom: 20,
    },
    presetBtn: (active) => ({
      padding: "8px 6px",
      borderRadius: 8,
      border: `1px solid ${active ? "#7ef4cc" : "rgba(126,244,204,0.2)"}`,
      background: active ? "rgba(126,244,204,0.12)" : "transparent",
      color: active ? "#7ef4cc" : "#c9d1e0",
      cursor: "pointer",
      fontSize: 11,
      fontFamily: "'Space Mono', monospace",
      transition: "all 0.15s",
    }),
    paletteRow: {
      display: "flex",
      gap: 6,
      flexWrap: "wrap",
      marginBottom: 20,
    },
    paletteChip: (active) => ({
      padding: "5px 10px",
      borderRadius: 20,
      border: `1px solid ${active ? "#7ef4cc" : "rgba(126,244,204,0.2)"}`,
      background: active ? "rgba(126,244,204,0.15)" : "transparent",
      color: active ? "#7ef4cc" : "#8a9aaa",
      cursor: "pointer",
      fontSize: 11,
      fontFamily: "'Space Mono', monospace",
      transition: "all 0.15s",
    }),
    canvas: {
      display: "flex",
      flexDirection: "column",
      gap: 16,
    },
    imgBox: {
      borderRadius: 12,
      border: "1px solid rgba(126,244,204,0.15)",
      overflow: "hidden",
      background: "#040a14",
      position: "relative",
      minHeight: 300,
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
    },
    progressBar: {
      position: "absolute",
      bottom: 0,
      left: 0,
      height: 3,
      width: `${progress}%`,
      background: "linear-gradient(90deg, #7ef4cc, #4dd9f0)",
      transition: "width 0.3s ease",
      borderRadius: "0 3px 3px 0",
    },
    imgRow: {
      display: "grid",
      gridTemplateColumns: "1fr 1fr",
      gap: 12,
    },
    imgLabel: {
      fontSize: 10,
      letterSpacing: 2,
      color: "#5a7a8a",
      padding: "8px 12px",
      textTransform: "uppercase",
    },
    errorBox: {
      background: "rgba(255,60,60,0.1)",
      border: "1px solid rgba(255,60,60,0.3)",
      borderRadius: 8,
      padding: "12px 16px",
      color: "#ff8080",
      fontSize: 12,
      marginBottom: 16,
    },
    promptInput: {
      width: "100%",
      background: "rgba(14,22,38,0.8)",
      border: "1px solid rgba(126,244,204,0.2)",
      borderRadius: 10,
      padding: "12px 14px",
      color: "#e8edf5",
      fontSize: 13,
      fontFamily: "'Space Mono', monospace",
      outline: "none",
      marginBottom: 12,
      boxSizing: "border-box",
      resize: "vertical",
      minHeight: 80,
    },
    placeholder: {
      color: "#2a3a4a",
      fontSize: 13,
      textAlign: "center",
    },
  };

  return (
    <div style={styles.app}>
      <link
        href="https://fonts.googleapis.com/css2?family=Space+Mono:wght@400;700&display=swap"
        rel="stylesheet"
      />
      <div style={styles.grid} />
      <div style={styles.content}>
        {/* Header */}
        <div style={styles.header}>
          <div style={styles.logo}>⬛ PIXEL FORGE</div>
          <div style={styles.tagline}>TRANSFORM ANY IMAGE INTO PIXEL ART · AI-POWERED · FACE-AWARE</div>
        </div>

        <div style={styles.main}>
          {/* Left Panel — Controls */}
          <div>
            <div style={styles.panel}>
              {/* Input Mode */}
              <div style={styles.sectionTitle}>Input Mode</div>
              <div style={styles.tabRow}>
                <button style={styles.tab(activeTab === "upload")} onClick={() => setActiveTab("upload")}>
                  📁 Upload
                </button>
                <button style={styles.tab(activeTab === "prompt")} onClick={() => setActiveTab("prompt")}>
                  ✨ Generate
                </button>
              </div>

              {activeTab === "upload" && (
                <>
                  <div
                    style={styles.dropzone(dragOver)}
                    onDragOver={(e) => { e.preventDefault(); setDragOver(true); }}
                    onDragLeave={() => setDragOver(false)}
                    onDrop={onDrop}
                    onClick={() => fileRef.current.click()}
                  >
                    <div style={{ fontSize: 32, marginBottom: 8 }}>🖼️</div>
                    <div style={{ color: "#7ef4cc", fontSize: 13, marginBottom: 4 }}>Drop image here</div>
                    <div style={{ color: "#4a6070", fontSize: 11 }}>or click to browse</div>
                    <input
                      ref={fileRef}
                      type="file"
                      accept="image/*"
                      style={{ display: "none" }}
                      onChange={(e) => handleFile(e.target.files[0])}
                    />
                  </div>
                  {uploadedB64 && (
                    <div style={{ fontSize: 11, color: "#5a9a7a", marginBottom: 12 }}>
                      ✓ Image loaded — ready to process
                    </div>
                  )}
                </>
              )}

              {activeTab === "prompt" && (
                <>
                  <textarea
                    style={styles.promptInput}
                    placeholder="Describe your image... e.g. 'a samurai in neon city at night'"
                    value={prompt}
                    onChange={(e) => setPrompt(e.target.value)}
                  />
                  <div style={{ fontSize: 10, color: "#4a5a6a", marginBottom: 12, letterSpacing: 1 }}>
                    Requires OPENAI_API_KEY in .env
                  </div>
                </>
              )}

              {/* Presets */}
              <div style={styles.sectionTitle}>Presets</div>
              <div style={styles.presetGrid}>
                {PRESETS.map((p) => (
                  <button
                    key={p.label}
                    style={styles.presetBtn(
                      palette === p.palette && pixelSize === p.pixel_size && numColors === p.num_colors
                    )}
                    onClick={() => applyPreset(p)}
                  >
                    {p.label}
                  </button>
                ))}
              </div>

              {/* Palette */}
              <div style={styles.sectionTitle}>Color Palette</div>
              <div style={styles.paletteRow}>
                {PALETTES.map((p) => (
                  <button
                    key={p.id}
                    style={styles.paletteChip(palette === p.id)}
                    onClick={() => setPalette(p.id)}
                  >
                    {p.emoji} {p.label}
                  </button>
                ))}
              </div>

              {/* Sliders */}
              <div style={styles.sectionTitle}>Pixel Settings</div>
              <Slider label="Pixel Size" value={pixelSize} min={2} max={64} onChange={setPixelSize} unit="px" />
              <Slider label="Color Count" value={numColors} min={2} max={256} onChange={setNumColors} />

              {/* Face Controls */}
              <div style={styles.sectionTitle}>Face Detection</div>
              <Toggle label="Protect faces (keep faces clear)" checked={protectFaces} onChange={setProtectFaces} />
              {!protectFaces && (
                <Slider
                  label="Face Pixel Size"
                  value={facePixelSize}
                  min={4}
                  max={64}
                  onChange={setFacePixelSize}
                  unit="px"
                />
              )}

              {/* Options */}
              <div style={styles.sectionTitle}>Options</div>
              <Toggle label="Show pixel grid overlay" checked={addGrid} onChange={setAddGrid} />

              {error && <div style={styles.errorBox}>⚠ {error}</div>}

              {activeTab === "upload" ? (
                <button
                  style={styles.btn("primary")}
                  onClick={process}
                  disabled={!uploadedB64 || loading}
                >
                  {loading ? "⬛ PROCESSING..." : "⬛ PIXELATE IMAGE"}
                </button>
              ) : (
                <button
                  style={styles.btn("primary")}
                  onClick={generate}
                  disabled={!prompt.trim() || loading}
                >
                  {loading ? "✨ GENERATING..." : "✨ GENERATE & PIXELATE"}
                </button>
              )}

              {resultB64 && (
                <button style={{ ...styles.btn("secondary"), marginTop: 10 }} onClick={download}>
                  ⬇ DOWNLOAD PNG
                </button>
              )}
            </div>
          </div>

          {/* Right Panel — Canvas */}
          <div style={styles.canvas}>
            <div style={styles.panel}>
              <div style={styles.sectionTitle}>Preview</div>

              {!uploadedB64 && !resultB64 && (
                <div style={{ ...styles.imgBox, minHeight: 400 }}>
                  <div style={styles.placeholder}>
                    <div style={{ fontSize: 48, marginBottom: 12 }}>⬛</div>
                    <div>Upload an image or generate one with AI</div>
                    <div style={{ fontSize: 11, marginTop: 6, color: "#1e2e3e" }}>
                      Supports faces, landscapes, portraits, artwork
                    </div>
                  </div>
                </div>
              )}

              {(uploadedB64 || resultB64) && (
                <div style={styles.imgRow}>
                  {uploadedB64 && (
                    <div>
                      <div style={styles.imgLabel}>Original</div>
                      <div style={styles.imgBox}>
                        <img
                          src={uploadedB64}
                          alt="Original"
                          style={{ width: "100%", display: "block", borderRadius: 8 }}
                        />
                      </div>
                    </div>
                  )}

                  <div>
                    <div style={styles.imgLabel}>{loading ? "Processing..." : "Pixelated"}</div>
                    <div style={styles.imgBox}>
                      {loading && (
                        <>
                          <div style={styles.placeholder}>
                            <div style={{ fontSize: 36, animation: "spin 1s linear infinite" }}>⬛</div>
                            <div style={{ marginTop: 12 }}>Applying pixel magic...</div>
                          </div>
                          <div style={styles.progressBar} />
                        </>
                      )}
                      {!loading && resultB64 && (
                        <img
                          src={resultB64}
                          alt="Pixelated"
                          style={{ width: "100%", display: "block", borderRadius: 8, imageRendering: "pixelated" }}
                        />
                      )}
                      {!loading && !resultB64 && (
                        <div style={styles.placeholder}>Awaiting processing</div>
                      )}
                    </div>
                  </div>
                </div>
              )}
            </div>

            {/* Info Cards */}
            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 12 }}>
              {[
                { icon: "🔲", title: "Pixel Grid", desc: "Custom pixel sizes from 2px to 64px blocks" },
                { icon: "🎨", title: "5 Palettes", desc: "Game Boy, NES, C64, Cyberpunk & more" },
                { icon: "👤", title: "Face-Aware", desc: "Auto-detects faces — protect or pixelate" },
              ].map((card) => (
                <div
                  key={card.title}
                  style={{
                    ...styles.panel,
                    padding: 16,
                    textAlign: "center",
                    border: "1px solid rgba(126,244,204,0.08)",
                  }}
                >
                  <div style={{ fontSize: 24, marginBottom: 8 }}>{card.icon}</div>
                  <div style={{ fontSize: 12, color: "#7ef4cc", marginBottom: 4, fontWeight: 700 }}>
                    {card.title}
                  </div>
                  <div style={{ fontSize: 11, color: "#4a6070", lineHeight: 1.5 }}>{card.desc}</div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
