"""
PixelForge Backend — FastAPI server
Handles image upload, pixelation, face detection, and color palette effects.
"""

import os
import io
import uuid
import base64
import asyncio
from pathlib import Path
from typing import Optional, List

import numpy as np
from PIL import Image, ImageFilter, ImageDraw
import cv2

from fastapi import FastAPI, File, UploadFile, HTTPException, Form
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse, FileResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel
from dotenv import load_dotenv

load_dotenv()

# ── Config ────────────────────────────────────────────────────────────────────

HOST = os.getenv("HOST", "0.0.0.0")
PORT = int(os.getenv("PORT", 8000))
DEBUG = os.getenv("DEBUG", "False").lower() == "true"
UPLOAD_DIR = Path(os.getenv("UPLOAD_DIR", "uploads"))
OUTPUT_DIR = Path(os.getenv("OUTPUT_DIR", "outputs"))
MAX_FILE_SIZE_MB = int(os.getenv("MAX_FILE_SIZE_MB", 20))
ALLOWED_ORIGINS = os.getenv(
    "ALLOWED_ORIGINS", "http://localhost:3000,http://127.0.0.1:3000"
).split(",")
DEFAULT_PIXEL_SIZE = int(os.getenv("DEFAULT_PIXEL_SIZE", 16))
MAX_PIXEL_SIZE = int(os.getenv("MAX_PIXEL_SIZE", 64))
MIN_PIXEL_SIZE = int(os.getenv("MIN_PIXEL_SIZE", 2))

UPLOAD_DIR.mkdir(parents=True, exist_ok=True)
OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

# ── App ───────────────────────────────────────────────────────────────────────

app = FastAPI(title="PixelForge API", version="1.0.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=ALLOWED_ORIGINS,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.mount("/outputs", StaticFiles(directory=str(OUTPUT_DIR)), name="outputs")

# ── Haar Cascade face detector (bundled with OpenCV) ─────────────────────────

FACE_CASCADE_PATH = cv2.data.haarcascades + "haarcascade_frontalface_default.xml"
face_cascade = cv2.CascadeClassifier(FACE_CASCADE_PATH)

# ── Pixel Art Engine ──────────────────────────────────────────────────────────


def pil_to_cv(img: Image.Image) -> np.ndarray:
    return cv2.cvtColor(np.array(img.convert("RGB")), cv2.COLOR_RGB2BGR)


def cv_to_pil(arr: np.ndarray) -> Image.Image:
    return Image.fromarray(cv2.cvtColor(arr, cv2.COLOR_BGR2RGB))


def detect_faces(cv_img: np.ndarray) -> List[tuple]:
    gray = cv2.cvtColor(cv_img, cv2.COLOR_BGR2GRAY)
    faces = face_cascade.detectMultiScale(
        gray, scaleFactor=1.1, minNeighbors=5, minSize=(30, 30)
    )
    if len(faces) == 0:
        return []
    return [(int(x), int(y), int(w), int(h)) for x, y, w, h in faces]


def pixelate_region(img: Image.Image, pixel_size: int) -> Image.Image:
    """Downscale then upscale to create blocky pixel effect."""
    w, h = img.size
    small_w = max(1, w // pixel_size)
    small_h = max(1, h // pixel_size)
    small = img.resize((small_w, small_h), Image.NEAREST)
    return small.resize((w, h), Image.NEAREST)


def quantize_colors(img: Image.Image, num_colors: int = 16) -> Image.Image:
    """Reduce palette to N colors for a retro look."""
    rgb = img.convert("RGB")
    quantized = rgb.quantize(colors=num_colors, method=Image.Quantize.MEDIANCUT)
    return quantized.convert("RGB")


def apply_pixel_art(
    img: Image.Image,
    pixel_size: int,
    num_colors: int,
    protect_faces: bool,
    face_pixel_size: int,
) -> Image.Image:
    """
    Main pixel-art pipeline:
    1. Quantize colors
    2. Pixelate the whole image
    3. If protect_faces=True, de-pixelate face regions (clear faces)
       Otherwise apply stronger pixelation to faces
    """
    pixel_size = max(MIN_PIXEL_SIZE, min(MAX_PIXEL_SIZE, pixel_size))
    num_colors = max(2, min(256, num_colors))

    result = quantize_colors(img, num_colors)
    result = pixelate_region(result, pixel_size)

    cv_img = pil_to_cv(img)
    faces = detect_faces(cv_img)

    if faces:
        result_arr = np.array(result)
        orig_arr = np.array(img.convert("RGB"))

        for x, y, w, h in faces:
            # Add a little padding around the face
            pad = int(min(w, h) * 0.1)
            x1, y1 = max(0, x - pad), max(0, y - pad)
            x2, y2 = min(img.width, x + w + pad), min(img.height, y + h + pad)

            face_region = img.crop((x1, y1, x2, y2))

            if protect_faces:
                # Clear, sharp face — just slight color reduction
                clear_face = quantize_colors(face_region, min(num_colors * 4, 128))
                result_arr[y1:y2, x1:x2] = np.array(clear_face)
            else:
                # Heavy pixelation on faces
                heavy = pixelate_region(face_region, face_pixel_size)
                result_arr[y1:y2, x1:x2] = np.array(heavy)

        result = Image.fromarray(result_arr)

    return result


def add_pixel_grid_overlay(img: Image.Image, pixel_size: int, opacity: int = 30) -> Image.Image:
    """Draw a subtle grid to emphasise pixel structure."""
    overlay = Image.new("RGBA", img.size, (0, 0, 0, 0))
    draw = ImageDraw.Draw(overlay)
    w, h = img.size
    color = (0, 0, 0, opacity)
    for x in range(0, w, pixel_size):
        draw.line([(x, 0), (x, h)], fill=color, width=1)
    for y in range(0, h, pixel_size):
        draw.line([(0, y), (w, y)], fill=color, width=1)
    base = img.convert("RGBA")
    combined = Image.alpha_composite(base, overlay)
    return combined.convert("RGB")


PALETTE_PRESETS = {
    "gameboy": [(15, 56, 15), (48, 98, 48), (139, 172, 15), (155, 188, 15)],
    "nes": [
        (0,0,0),(252,252,252),(248,0,0),(0,168,68),(0,88,248),
        (248,120,0),(228,0,88),(0,228,248),(104,68,252),(0,188,188),
        (164,0,0),(168,168,0),(168,228,0),(68,0,188),(148,0,132),
        (248,248,0),
    ],
    "commodore64": [
        (0,0,0),(255,255,255),(136,0,0),(170,255,238),(204,68,204),
        (0,204,85),(0,0,170),(238,238,119),(221,136,85),(102,68,0),
        (255,119,119),(51,51,51),(119,119,119),(170,255,102),(0,136,255),
        (187,187,187),
    ],
    "pastel": [
        (255,179,186),(255,223,186),(255,255,186),(186,255,201),
        (186,225,255),(218,186,255),(255,186,230),(240,240,240),
    ],
    "cyberpunk": [
        (0,0,0),(255,0,128),(0,255,255),(255,255,0),(128,0,255),
        (0,128,255),(255,128,0),(255,255,255),
    ],
}


def apply_palette(img: Image.Image, palette_name: str) -> Image.Image:
    """Map every pixel to the nearest color in a preset palette."""
    if palette_name not in PALETTE_PRESETS:
        return img

    palette_colors = np.array(PALETTE_PRESETS[palette_name], dtype=np.float32)
    arr = np.array(img.convert("RGB"), dtype=np.float32)
    h, w, _ = arr.shape
    flat = arr.reshape(-1, 3)

    # Vectorised nearest-neighbor in RGB space
    diffs = flat[:, None, :] - palette_colors[None, :, :]       # (N, K, 3)
    dists = np.sum(diffs ** 2, axis=2)                           # (N, K)
    indices = np.argmin(dists, axis=1)                           # (N,)
    mapped = palette_colors[indices].reshape(h, w, 3).astype(np.uint8)
    return Image.fromarray(mapped)


def img_to_b64(img: Image.Image, fmt: str = "PNG") -> str:
    buf = io.BytesIO()
    img.save(buf, format=fmt)
    return base64.b64encode(buf.getvalue()).decode()


# ── Routes ────────────────────────────────────────────────────────────────────


class ProcessRequest(BaseModel):
    image_b64: str
    pixel_size: int = DEFAULT_PIXEL_SIZE
    num_colors: int = 16
    protect_faces: bool = True
    face_pixel_size: int = 8
    add_grid: bool = False
    palette: Optional[str] = None


@app.get("/")
async def root():
    return {"message": "PixelForge API is running", "version": "1.0.0"}


@app.get("/palettes")
async def list_palettes():
    return {"palettes": list(PALETTE_PRESETS.keys())}


@app.post("/process")
async def process_image(req: ProcessRequest):
    try:
        # Decode base64 image
        header, _, data = req.image_b64.partition(",")
        if not data:
            data = req.image_b64
        raw = base64.b64decode(data)
        img = Image.open(io.BytesIO(raw)).convert("RGB")

        # Size guard
        max_dim = 2048
        if img.width > max_dim or img.height > max_dim:
            img.thumbnail((max_dim, max_dim), Image.LANCZOS)

        # Pipeline
        result = apply_pixel_art(
            img,
            pixel_size=req.pixel_size,
            num_colors=req.num_colors,
            protect_faces=req.protect_faces,
            face_pixel_size=req.face_pixel_size,
        )

        if req.palette and req.palette in PALETTE_PRESETS:
            result = apply_palette(result, req.palette)

        if req.add_grid:
            result = add_pixel_grid_overlay(result, req.pixel_size)

        # Save to output dir
        filename = f"{uuid.uuid4().hex}.png"
        out_path = OUTPUT_DIR / filename
        result.save(out_path, format="PNG")

        return {
            "success": True,
            "result_b64": "data:image/png;base64," + img_to_b64(result),
            "filename": filename,
            "download_url": f"/outputs/{filename}",
            "dimensions": {"width": result.width, "height": result.height},
        }

    except Exception as exc:
        raise HTTPException(status_code=500, detail=str(exc))


@app.post("/upload")
async def upload_image(file: UploadFile = File(...)):
    """Accept a raw file upload, return base64 for the frontend."""
    content = await file.read()
    size_mb = len(content) / (1024 * 1024)
    if size_mb > MAX_FILE_SIZE_MB:
        raise HTTPException(
            status_code=413,
            detail=f"File too large ({size_mb:.1f} MB). Max {MAX_FILE_SIZE_MB} MB.",
        )
    b64 = "data:image/png;base64," + base64.b64encode(content).decode()
    return {"success": True, "image_b64": b64, "filename": file.filename}


@app.post("/generate-prompt")
async def generate_from_prompt(prompt: str = Form(...), style: str = Form("pixel")):
    """
    Placeholder for AI image generation.
    Wire up OPENAI_API_KEY or STABILITY_API_KEY in .env to enable.
    """
    openai_key = os.getenv("OPENAI_API_KEY", "")
    if not openai_key or openai_key == "your_openai_api_key_here":
        raise HTTPException(
            status_code=501,
            detail="AI generation requires OPENAI_API_KEY in .env. "
                   "Upload your own image to pixelate it instead.",
        )

    try:
        import openai as oai
        client = oai.AsyncOpenAI(api_key=openai_key)
        full_prompt = f"{prompt}, {style} art style, vibrant colors, detailed"
        resp = await client.images.generate(
            model="dall-e-3", prompt=full_prompt, size="1024x1024", n=1
        )
        image_url = resp.data[0].url

        import httpx
        async with httpx.AsyncClient() as hc:
            img_resp = await hc.get(image_url)
        img = Image.open(io.BytesIO(img_resp.content)).convert("RGB")

        result = apply_pixel_art(img, pixel_size=16, num_colors=16,
                                 protect_faces=True, face_pixel_size=8)

        filename = f"gen_{uuid.uuid4().hex}.png"
        out_path = OUTPUT_DIR / filename
        result.save(out_path, format="PNG")

        return {
            "success": True,
            "result_b64": "data:image/png;base64," + img_to_b64(result),
            "filename": filename,
            "download_url": f"/outputs/{filename}",
        }

    except Exception as exc:
        raise HTTPException(status_code=500, detail=str(exc))


# ── Entry point ───────────────────────────────────────────────────────────────

if __name__ == "__main__":
    import uvicorn
    uvicorn.run("main:app", host=HOST, port=PORT, reload=DEBUG)
